#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;

int main(){

ll t;
cin>>t;
ll x,y;
	while(t--){

		cin>>x>>y;

		if(x==y){
			cout<<"yes"<<endl;
			
		}

		else if(x<y && x==1){
			cout<<"no"<<endl;
		}

		else{

			if(x>y){
				cout<<"yes"<<endl;
			}

			else{

				if(x%2==0){
					while(x%2==0 && x<y){
					x=(x*3)/2;
						}
					

					

				if(x>=y){
								
					cout<<"yes"<<endl;

				}

				else{
						cout<<"no"<<endl;
					}

				
				}
				else{
					
					while(x%2==0 && x<y){
					x=(x*3)/2;
					}

					if(x>=y){
						cout<<"yes"<<endl;
					}
					else{
						cout<<"no"<<endl;
					}
					
				}

				

			}	

				


			}




		}











	











	return 0;
}