#include <bits/stdc++.h>
typedef long long int ll;
using namespace std;
int main(){

ll t,n,s,k,ele,locate,steps_up,steps_down;
bool flag=true;
cin>>t;
std::vector<ll> measure;
	while(t--){
		flag=true;
		cin>>n>>s>>k;

		for(ll i=0;i<k;i++){
			cin>>ele;
			measure.push_back(ele);
		}
		sort(measure.begin(),measure.end());

		for(ll i=0;i<measure.size();i++){
			if(s==measure[i]){
				flag=false;
				locate=i;
			}


		}

		if(flag==true){
			cout<<0<<endl;
			measure.clear();
			continue;
		}
		// if floor is open(above case)

		//if floor is closed(below case)
		ll counter=1;
		steps_up=1;
		steps_down=1;
		for(ll i=locate;i<measure.size();i++){
			if(measure[i]==s+counter){
				steps_up++;
			}

			counter++;
		}
		counter=1;
		for(ll i=locate;i>=0;i--){
			if(measure[i]==s-counter){
				steps_down++;
				if(i==0){
					steps_down=1000000000000;
				}
			}
			counter++;



		}


		cout<<min(steps_down,steps_up)<<endl;



		measure.clear();
	}


	return 0;
}