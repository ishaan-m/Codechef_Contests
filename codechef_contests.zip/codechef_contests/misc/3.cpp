#include <bits/stdc++.h>
using namespace std;

const int M=4;
const int N=4;
//typedef long long int;
#define int long long

vector<string> vec;
vector<string> vec2;
int movief(char c,int arr[M][N]){


	if(c=='A'){
		return 0;
	}

	if(c=='B'){
		return 1;
	}

	if(c=='C'){
		return 2;
	}

	if(c=='D'){
		return 3;
	}



	return -1;
}


int slotf(int slot,int arr[M][N]){


	if(slot==12){
		return 0;
	}

	if(slot==3){
		return 1;
	}

	if(slot==6){
		return 2;
	}

	if(slot==9){
		return 3;
	}



	return -1;
}

void permute(string a,int l,int r)  
{  
    
    if(l==r){
    	vec.push_back(a);
    }
    else{
         
        for (int i = l; i <= r; i++)  
        {  
  
            
            swap(a[l], a[i]);  
   
            permute(a, l+1, r);  
  
         
            swap(a[l], a[i]);  
        }  

    }
     
}  




int main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int finalsum=0;
    int t;
    cin>>t;
    int n;
    char movie;
    int slot;
    	int arr[4][4];
    
    string per="1234";

    	permute(per,0,3);
    while(t--){
    	cin>>n;
    	
    	if(n==0){
    	    cout<<-400<<endl;
    	    finalsum=finalsum-400;
    	    continue;
    	}
    

    	for(int i=0;i<4;i++){
    		for(int j=0;j<4;j++){
    			arr[i][j]=0;
    		}
    	}
    	for(int i=0;i<n;i++){
    		cin>>movie>>slot;
    		arr[movief(movie,arr)][slotf(slot,arr)]++;
    	}

    	
    	string s;
        int a;
        char c;
        string sas;
	    for(int i=0;i<24;i++){
	    	std::vector<int> ;
		    s=vec[i];
		     sas="";

		    for(int j=0;j<4;j++){
			
			   a=arr[s[j]-49][j];
			    
			    c=(char)(a+48);
			  //  cout<<c<<endl;
			    sas=sas+c;
		    }
		    //cout<<sas<<endl;
		    vec2.push_back(sas);


	    }
    // cout<<vec2.size()<<endl;
    // 	for(int i=0;i<vec.size();i++){
    // 		cout<<vec[i]<<" ";
    // 	}
    //     cout<<endl;
    // 	for(int i=0;i<vec2.size();i++){
    // 		cout<<vec2[i]<<" ";
    // 	}
        string final;
        int maxi=-1000;
        int sum=0;
        int zcount=0;
        for(int i=0;i<24;i++){
            zcount=0;
            final=vec2[i];
            sort(final.begin(),final.end());
            for(int j=0;j<4;j++){
                if(final[j]=='0'){
                    zcount++;
                }
            }
          sum=(final[3]-48)*100+(final[2]-48)*75+(final[1]-48)*50+(final[0]-48)*25-(zcount*100);
            maxi=max(sum,maxi);
        }
        
        cout<<maxi;
        

        
         finalsum=finalsum+maxi;

        vec2.clear();

    	cout<<endl;

    }
    cout<<finalsum;
   
    return 0;
}