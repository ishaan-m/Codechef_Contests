#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
int main(){

	ll t,gg;
	ll l,r,ele,sum=0;
	ll flagger=0;
	cin>>t;
	std::vector<ll> v;
	while(t--){
		flagger=0;
		cin>>l>>r;

		v.push_back(l);
		sum=l;
		for(ll i=l;i<=r;i++){
			gg=((v[flagger]&(i+1)));
			v.push_back(gg);
			sum=sum+gg;
			flagger++;
		}

		cout<<sum<<endl;
		sum=0;
		v.clear();


	}




	return 0;
}