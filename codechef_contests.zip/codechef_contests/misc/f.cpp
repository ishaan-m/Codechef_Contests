#include <bits/stdc++.h>
using namespace std;
typedef long long int ll;
int main(void){
    
    ll t;
    cin>>t;
    ll n,total;
    bool flag=false;
    bool flag2=false;
    while(t--){
        flag=false;
        flag2=false;
        cin>>n>>total;
        ll sum=0;
        ll arr[n];
        ll output[n];
        
        for(ll i=0;i<n;i++){
            cin>>arr[i];
        }
        
        sort(arr,arr+n);
        
        for(ll i=0;i<n;i++){
            if(total%arr[i]!=0){
                flag=true;
            }
        }
        
        if(flag==false){
            cout<<"NO"<<endl;
            continue;
        }
        ll index;
        for(ll i=0;i<n;i++){
            if(arr[i]>total){
                flag2=true;
                index=i;
                break;
            }
        }
        //case is one coin is bigger than total
        if(flag2){
            cout<<"YES ";
            for(ll i=0;i<n;i++){
                output[i]=0;
            }
            
            output[index]=1;
            
            for(ll i=0;i<n;i++){
                cout<<output[i]<<" ";
                
            }
            cout<<endl;
            continue;
        }
        
        //case if largest coin is less than total
        ll counter=0;
        ll counter2=0;
        ll finalindex;
	for(ll i=n-1;i>0;i--){
		if(total>arr[n-1]){
			finalindex=i;
            break;	
		}
	
	}

        while(sum<total){
            sum=sum+arr[finalindex];
            counter++;
        }
        counter--;
        sum=sum-arr[finalindex];

        while(sum<total){
            sum=sum+arr[0];
            counter2++;
        }

        if(finalindex==0){
            counter++;
        }

        for (ll i = 0; i < n; ++i)
        {
            /* code */
            output[i]=0;
        }
        output[0]=counter2;
        output[finalindex]=counter;

        


        cout<<"YES ";
        for(ll i=0;i<n;i++){
            cout<<output[i]<<" ";
        }
        
        cout<<endl;
        
        
    }
    
    // Your code here!
    
}