#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef unsigned long long ull;

typedef vector<int> vi;
typedef pair<int, int> ii;
typedef vector<ii> vii;
typedef vector<vi> vvi;
typedef vector<vii> vvii;

#define INF INT_MAX
#define MOD 1000000007
#define all(x) x.begin(), x.end()

int main(){
	ios::sync_with_stdio(false);
	cin.tie(NULL);

	int T; cin >> T;
	while(T--){
	    int N, K; cin >> N >> K;
	    vvi Adj(N);

	    for(int n = 0; n < N; n++){
	        for(int i = 0; i < N; i++){
	            char c; cin >> c;
	            if(c == '0' or n == i) continue;
	            if(abs(n - i) <= K) Adj[n].push_back(i);
	        }
	    }

	    vi Dist(N, -1); Dist[0] = 0;
	    queue<int> Q; Q.push(0);

	    while(!Q.empty()){
	        int u = Q.front(); Q.pop();
	        for(auto i : Adj[u]){
	            if(Dist[i] != -1) continue;
	            Dist[i] = Dist[u] + 1;
	            Q.push(i);
	        }
	    }
	    cout << Dist[N - 1] << endl;
	}

	return 0;
}